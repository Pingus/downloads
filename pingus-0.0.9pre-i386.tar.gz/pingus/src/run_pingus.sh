#! /bin/sh

echo "Starting pingus..."

echo 1 | ./pingus -p ../data/ -l ../data/level3.plf > pingus.log
tail pingus.log
