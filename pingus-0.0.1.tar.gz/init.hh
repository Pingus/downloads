// Copyright (C) 1998 Ingo Ruhnke <grumbel@gmx.de>, see README.TXT for details

#ifndef INIT_HH
#define INIT_HH

void check_args(int argc, char* argv[]);
void init(void);

#endif

/* EOF */
