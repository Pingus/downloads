// Copyright (C) 1998 Ingo Ruhnke <grumbel@gmx.de>, see README.TXT for details

#ifndef GAME_HH
#define GAME_HH

void game(void);

#endif

/* EOF */
