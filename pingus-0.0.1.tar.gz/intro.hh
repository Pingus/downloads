// Copyright (C) 1998 Ingo Ruhnke <grumbel@gmx.de>, see README.TXT for details

#ifndef INTRO_HH
#define INTRO_HH

void intro(void);

#endif

/* EOF */
