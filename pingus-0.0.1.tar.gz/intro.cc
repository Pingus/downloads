// Copyright (C) 1998 Ingo Ruhnke <grumbel@gmx.de>, see README.TXT for details

#include <stdio.h>
#include "intro.hh"

void
intro(void)
{
  puts(
       "Pingus V0.0 Intro\n"
       "-----------------\n");
}

/* EOF */
