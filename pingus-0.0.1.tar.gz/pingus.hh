// Copyright (C) 1998 Ingo Ruhnke <grumbel@gmx.de>, see README.TXT for details

#ifndef PINGUS_HH
#define PINGUS_HH

/*
class PingusMain : public CL_ClanApplication
{

public:
  char *get_title(void);
  void intro(void);
  void extro(void);
  void check_args(int argc, char* argv[]);
  int  main(int argc, char* argv[]);

private:
  CL_InputSourceProvider *datafile;

} my_app; // notice this line. It creates the global instance.
*/
#endif

/* EOF */
