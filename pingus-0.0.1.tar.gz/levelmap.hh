// Copyright (C) 1998 Ingo Ruhnke <grumbel@gmx.de>, see README.TXT for details

#ifndef LEVELMAP_HH
#define LEVELMAP_HH


#endif

/* EOF */
